// Snake: see GAME.md.
